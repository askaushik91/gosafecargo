<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - YesGoCargo</title>

    <?php include'assets/includes/files.php' ?>
</head>
<body id="gallery">
    <!--Header Starts-->
    <?php include'assets/includes/header.php' ?>

    <!--Banner Starts-->
    <div class="galleryBanner">
            <img id="galleryImage" src="assets/media/images/one.jpeg" alt="YesGoimages">
        <div class="overlayBg"></div>
    </div>

    <div class="galleryItems">
        <div class="container">
            <ul>
                <li><img src="assets/media/images/one.jpeg" /></li>
                <li><img src="assets/media/images/two.jpeg" /></li>
                <li><img src="assets/media/images/three.jpeg" /></li>
                <li><img src="assets/media/images/four.jpeg" /></li>

                <li><img src="assets/media/images/one.jpeg" /></li>
                <li><img src="assets/media/images/two.jpeg" /></li>
                <li><img src="assets/media/images/three.jpeg" /></li>
                <li><img src="assets/media/images/four.jpeg" /></li>

                <li><img src="assets/media/images/one.jpeg" /></li>
                <li><img src="assets/media/images/two.jpeg" /></li>
                <li><img src="assets/media/images/three.jpeg" /></li>
                <li><img src="assets/media/images/four.jpeg" /></li>

                <li><img src="assets/media/images/one.jpeg" /></li>
                <li><img src="assets/media/images/two.jpeg" /></li>
                <li><img src="assets/media/images/three.jpeg" /></li>
            </ul>
        </div>
    </div>

    <!--Footer-->
    <?php include'assets/includes/footer.php' ?>

    
    <?php include'assets/includes/scripts.php' ?>
    <script src="assets/js/gallery.js"></script>
</body>

</html>