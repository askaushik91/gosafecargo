<link rel="icon" href="assets/media/images/favicon.ico" />
<link rel="stylesheet" href="assets/css/style.css" />